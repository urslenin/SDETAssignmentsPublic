describe('Automation Test Suite - Fixtures', function () {

  //Use the cy.fixture() method to pull data from fixture file
  before(function () {
    cy.fixture('example').then(function (data) {
      this.data = data;
    })
  })

  it('Cypress Test Case - Understanding Fixtures', function () {
    
    //Provide the environment variables read from the cypress.env
    const url = Cypress.env('url')
    cy.visit(url);

    //Verify Page Title
    cy.title().should('eq', this.data.AutomationPandaPageTitle)
    //Click on Speaking menu    
    cy.get('#menu-item-10593 > a').click({force: true})
    /* Speaking Page Title*/
    cy.title().should('eq', this.data.SpeakingMenuTitle)
    /* Speaking Page loaded*/
    cy.wait(2000)
    cy.get('.entry-content').each( ($element, index, $list) =>{
      const text = $element.find('h2').text()
      
      if(text.includes('Keynote'))
      {
        cy.log(text)              
      }
    })
    cy.get('.entry-content > :nth-child(2)').should('have.text', this.data.SpeakingPageSuccess)
    
  })
})